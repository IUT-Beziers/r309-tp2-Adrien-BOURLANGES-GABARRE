from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
test = Tk()
test.title('TP2-adrien-bourlanges')
test.geometry('800x500')

imageswitch = Image.open("switch.png")
resize_imageswitch = imageswitch.resize((40, 40))
imgswitch2 = ImageTk.PhotoImage(resize_imageswitch)
label1 = Label(image=imgswitch2)
label1.image = imgswitch2
label1.pack()

imageclient = Image.open("client.jpg")
resize_imageclient = imageclient.resize((40, 40))
imgclient2 = ImageTk.PhotoImage(resize_imageclient)
label2 = Label(image=imgclient2)
label2.image = imgswitch2
label2.pack()

def valider():
    imagerouteur = Image.open("routeur.jpg")
    resize_imagerouteur = imagerouteur.resize((60, 60))
    imgrouteur2 = ImageTk.PhotoImage(resize_imagerouteur)
    label3 = Label(image=imgrouteur2)
    label3.image = imgswitch2
    label3.pack()
    print('ok')
buttonvali = Button(test, text="valider", command=valider)
buttonvali.pack(side=LEFT)

boutquit = Button(test,text='Quitter',command=test.quit)
boutquit.pack(side=BOTTOM)
test.mainloop()
test.destroy()