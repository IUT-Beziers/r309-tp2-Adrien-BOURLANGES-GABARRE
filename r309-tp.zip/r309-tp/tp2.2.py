from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk

test = Tk()
test.title("TP2-adrien-bourlanges") #marque un nom pour la fenétre
test.geometry("900x700")            #défine la taille de la fenétre
img1 = Image.open('client.png')     #ouvre l'images client.png 
img1 = img1.resize((50,50))         #la redimentionne 
img1=ImageTk.PhotoImage(img1)       #mes dans img1 limages utilisable du client
img2 = Image.open('switch.png')
img2 = img2.resize((50,50))
img2=ImageTk.PhotoImage(img2)
img3 = Image.open('routeur.png')
img3 = img3.resize((50,50))
img3=ImageTk.PhotoImage(img3)
img_cliq = ""

but1=ttk.Button(test, width = 10, text="client",command=lambda: choix(1))   #crée le bouton pour pouvoir posé des client (utilisise la boucle if pour définir limages utilisé)
but1.place(x=10,y=10)
but2=ttk.Button(test, width = 10, text="Switch",command=lambda: choix(2))
but2.place(x=100,y=10)
but3=ttk.Button(test, width = 10, text="Routeur",command=lambda: choix(3))
but3.place(x=190,y=10)
but4=ttk.Button(test, width = 10, text="sélection", command=lambda: choix(4))
but4.place(x=300,y=10)
butquit=ttk.Button(test, width = 10, text="quitter",command=test.quit)
butquit.place(x=400,y=10)
dessin=Canvas(test,bg="ivory",width=800,height=600)
dessin.pack(side='bottom')


def choix(val):               #c'est ici que l'on définie quelle images vas étre déposer selon le bouton que l'on a cliqué on vas metrre tel ou tel images selon le numéros du choix
	global img_cliq
	if val == 1:
		img_cliq = img1
	elif val == 2:
		img_cliq = img2
	elif val == 3:
		img_cliq = img3
	elif val == 4:
		img_cliq = ""
	
def keydown(e):                                          #ici on crées une images selon la touche que l'on apuis sur le clavier
	if e.char == "c":
		dessin.create_image(e.x-100,e.y-100,image=img1)
	if e.char == "s":
		dessin.create_image(e.x-100,e.y-100,image=img2)
	if e.char == "r":
		dessin.create_image(e.x-100,e.y-100,image=img3)



def clique(positions):
	if img_cliq != "" and positions.x > 25 and positions.y>30:
		dessin.create_image(positions.x,positions.y,image=img_cliq)
		placer = True



test.bind("<KeyPress>", keydown)
test.bind('<Button 1>',clique)
test.mainloop()
test.destroy()