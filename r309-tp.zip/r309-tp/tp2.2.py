from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk

test = Tk()
test.title("TP2-adrien-bourlanges") #marque un nom pour la fenétre
test.geometry("900x700")            #défine la taille de la fenétre
imageclient = Image.open('client.png')     #ouvre l'images client.png 
imageclient = imageclient.resize((50,50))         #la redimentionne 
imageclient=ImageTk.PhotoImage(imageclient)       #mes dans img1 limages utilisable du client
imageswitch = Image.open('switch.png')
imageswitch = imageswitch.resize((50,50))
imageswitch=ImageTk.PhotoImage(imageswitch)
imagerouteur = Image.open('routeur.png')
imagerouteur = imagerouteur.resize((50,50))
imagerouteur=ImageTk.PhotoImage(imagerouteur)
image_cliq = ""

but1=Button(test,width = 10,text="client",command=lambda: choix('client'))   #crée le bouton pour pouvoir posé des client (utilisise la boucle if pour définir limages utilisé)
but1.place(x=1,y=10)
but2=Button(test,width = 10,text="Switch",command=lambda: choix('switch'))
but2.place(x=100,y=10)
but3=Button(test,width = 10,text="Routeur",command=lambda: choix('routeur'))
but3.place(x=200,y=10)
but4=Button(test,width = 10,text="sélection",command=lambda: choix('sélection'))
but4.place(x=450,y=10)
butquit=Button(test,width = 10,text="quitter",bg='red',command=test.quit)
butquit.place(x=800,y=10)
dessin=Canvas(test,bg="ivory",width=850,height=650)
dessin.pack(side='bottom')


def choix(val):               #c'est ici que l'on définie quelle images vas étre déposer selon le bouton que l'on a cliqué on vas metrre tel ou tel images selon le numéros du choix
	global image_cliq
	if val == 'client':
		image_cliq = imageclient
	elif val == 'switch':
		image_cliq = imageswitch
	elif val == 'routeur':
		image_cliq = imagerouteur
	elif val == 'sélection':
		image_cliq = ""
	
def clavier(e):                                          #ici on crées une images selon la touche que l'on apuis sur le clavier
	if e.char == "c":
		dessin.create_image(e.x-20,e.y-50,image=imageclient)
	if e.char == "s":
		dessin.create_image(e.x-20,e.y-50,image=imageswitch)
	if e.char == "r":
		dessin.create_image(e.x-20,e.y-50,image=imagerouteur)


def clique(positions):
	if image_cliq != "" and positions.x > 25 and positions.y>30:
		dessin.create_image(positions.x,positions.y,image=image_cliq)
		placer = True



test.bind("<KeyPress>", clavier)
test.bind('<Button 1>',clique)
test.mainloop()
test.destroy()